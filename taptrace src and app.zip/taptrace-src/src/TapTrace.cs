using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Xml.Serialization;
using Forms = System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("TapTrace")]
[assembly: System.Reflection.AssemblyProduct("TapTrace")]
[assembly: System.Reflection.AssemblyDescription("Keyboard and mouse input overlay")]
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]

namespace TapTrace
{
    public static class Native
    {
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hwnd, int index);
        [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hwnd, int index, int value);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hwnd, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hwnd, int id);
        [DllImport("user32.dll", SetLastError = true)] public static extern bool RegisterRawInputDevices(RawDevice[] devices, uint count, uint size);
        [DllImport("user32.dll", SetLastError = true)] public static extern uint GetRawInputData(IntPtr input, uint command, [Out] byte[] data, ref uint size, uint headerSize);
        [DllImport("user32.dll", SetLastError = true)] public static extern uint GetRegisteredRawInputDevices([Out] RawDevice[] devices, ref uint count, uint size);
        [StructLayout(LayoutKind.Sequential)]
        public struct RawDevice
        {
            public ushort Page, Usage;
            public uint Flags;
            public IntPtr Target;
        }
    }

    public static class GameCompatibility
    {
        [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int id);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr token, int type, out int value, int length, out int returned);
        public static bool IsAdministrator()
        { using (var identity = WindowsIdentity.GetCurrent()) return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator); }
        public static bool ElevatedGame()
        {
            foreach (var process in Process.GetProcessesByName("VALORANT-Win64-Shipping"))
            {
                using (process)
                {
                    IntPtr handle = OpenProcess(0x1000, false, process.Id), token = IntPtr.Zero;
                    try
                    {
                        if (handle == IntPtr.Zero || !OpenProcessToken(handle, 8, out token)) continue;
                        int elevated, returned;
                        if (GetTokenInformation(token, 20, out elevated, 4, out returned) && elevated != 0) return true;
                    }
                    finally { if (token != IntPtr.Zero) CloseHandle(token); if (handle != IntPtr.Zero) CloseHandle(handle); }
                }
            }
            return false;
        }
    }

    public class Preferences
    {
        public double Scale = 1;
        public double Opacity = 0.92;
        public double X = 36;
        public double Y = 160;
        public int Theme;
        public bool Locked = true;
        public bool Visible = true;
        public void Validate()
        {
            Scale = FiniteClamp(Scale, 0.7, 1.8, 1);
            Opacity = FiniteClamp(Opacity, 0.3, 1, 0.92);
            X = FiniteClamp(X, -100000, 100000, 36);
            Y = FiniteClamp(Y, -100000, 100000, 160);
            Theme = Math.Max(0, Math.Min(2, Theme));
        }
        static double FiniteClamp(double n, double min, double max, double fallback)
        { return Double.IsNaN(n) || Double.IsInfinity(n) ? fallback : Math.Max(min, Math.Min(max, n)); }
    }

    public class Binding
    {
        public readonly int Key;
        public readonly string Label, Caption;
        public readonly Rect Bounds;
        public Binding(int key, string label, string caption, double x, double y, double w, double h)
        { Key = key; Label = label; Caption = caption; Bounds = new Rect(x, y, w, h); }
    }

    public class InputState
    {
        // Mouse 4 = XBUTTON1 (back); Mouse 5 = XBUTTON2 (forward).
        public static readonly Binding[] Bindings = {
            new Binding(0x57, "W", "", 84, 36, 62, 58),
            new Binding(0x41, "A", "", 14, 102, 62, 58),
            new Binding(0x53, "S", "", 84, 102, 62, 58),
            new Binding(0x44, "D", "", 154, 102, 62, 58),
            new Binding(0xA0, "L SHIFT", "", 14, 168, 97, 42),
            new Binding(0xA2, "L CTRL", "", 119, 168, 97, 42),
            new Binding(0x01, "LMB", "LEFT", 14, 230, 97, 48),
            new Binding(0x02, "RMB", "RIGHT", 119, 230, 97, 48),
            new Binding(0x05, "M4", "BACK", 14, 286, 97, 48),
            new Binding(0x06, "M5", "FORWARD", 119, 286, 97, 48)
        };
        public readonly bool[] Down = new bool[10];
        public readonly double[] LitUntil = new double[10];
        readonly bool[] previousLight = new bool[10];
        public readonly Stopwatch Clock = Stopwatch.StartNew();
        public string Last = "Press a key or mouse button";
        public bool Update(Func<int, bool> read) { return Update(read, null); }
        public bool Update(Func<int, bool> read, bool[] taps)
        {
            bool changed = false;
            double now = Clock.Elapsed.TotalMilliseconds;
            for (int i = 0; i < Bindings.Length; i++)
            {
                bool down = read(Bindings[i].Key);
                bool tap = taps != null && taps[i];
                if ((down && !Down[i]) || tap) Last = "Last input: " + Bindings[i].Label;
                if (down || tap) LitUntil[i] = now + 85;
                bool light = down || LitUntil[i] > now;
                changed |= Down[i] != down || previousLight[i] != light || tap;
                previousLight[i] = light;
                Down[i] = down;
            }
            return changed;
        }
        public bool IsLit(int i) { return Down[i] || LitUntil[i] > Clock.Elapsed.TotalMilliseconds; }
    }

    // Receives physical device events even when a game owns foreground input.
    // Kept on the window dispatcher: no hooks, injection, or polling of game state.
    public sealed class RawInputSource : IDisposable
    {
        readonly Dictionary<long, HashSet<int>> devices = new Dictionary<long, HashSet<int>>();
        readonly bool[] taps = new bool[10];
        readonly byte[] packet = new byte[64];
        readonly uint headerSize = (uint)(8 + 2 * IntPtr.Size);
        HwndSource source;
        string last;
        public long KeyboardPackets { get; private set; }
        public long MousePackets { get; private set; }
        public void Start(IntPtr target)
        {
            var registrations = new[] {
                new Native.RawDevice { Page = 1, Usage = 6, Flags = 0x2100, Target = target },
                new Native.RawDevice { Page = 1, Usage = 2, Flags = 0x2100, Target = target }
            }; // INPUTSINK, not EXINPUTSINK: keep receiving when the foreground game also uses Raw Input.
            source = HwndSource.FromHwnd(target);
            source.AddHook(Message);
            if (!Native.RegisterRawInputDevices(registrations, 2, (uint)Marshal.SizeOf(typeof(Native.RawDevice))))
            {
                source.RemoveHook(Message); source = null;
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), "Could not enable background keyboard and mouse input");
            }
        }
        IntPtr Message(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (message == 0x00FE && wParam.ToInt32() == 2) RemoveDevice(lParam.ToInt64());
            if (message == 0x00FF)
            {
                uint size = (uint)packet.Length;
                uint copied = Native.GetRawInputData(lParam, 0x10000003, packet, ref size, headerSize);
                if (copied != uint.MaxValue) Parse(packet, (int)copied, IntPtr.Size);
                // Let the default window procedure perform WM_INPUT cleanup.
            }
            return IntPtr.Zero;
        }
        public void Parse(byte[] data, int count, int pointerSize)
        {
            int header = 8 + 2 * pointerSize;
            if (data == null || count > data.Length || count < header || (pointerSize != 4 && pointerSize != 8)) return;
            uint type = BitConverter.ToUInt32(data, 0);
            long device = pointerSize == 8 ? BitConverter.ToInt64(data, 8) : BitConverter.ToUInt32(data, 8);
            if (type == 1 && count >= header + 16)
            {
                KeyboardPackets++;
                int scan = BitConverter.ToUInt16(data, header);
                int flags = BitConverter.ToUInt16(data, header + 2);
                int key = BitConverter.ToUInt16(data, header + 6);
                if (scan == 0xFF || key >= 0xFF) return;
                if (key == 0x10) key = scan == 0x36 ? 0xA1 : 0xA0;
                if (key == 0x11) key = (flags & 2) != 0 ? 0xA3 : 0xA2;
                SetKey(device, key, (flags & 1) == 0);
            }
            else if (type == 0 && count >= header + 24)
            {
                MousePackets++;
                // RAWMOUSE's button union starts at offset 4 (there is alignment padding).
                int flags = BitConverter.ToUInt16(data, header + 4);
                MouseButton(device, flags, 0x0001, 0x0002, 0x01);
                MouseButton(device, flags, 0x0004, 0x0008, 0x02);
                MouseButton(device, flags, 0x0040, 0x0080, 0x05);
                MouseButton(device, flags, 0x0100, 0x0200, 0x06);
            }
        }
        void MouseButton(long device, int flags, int press, int release, int key)
        { if ((flags & press) != 0) SetKey(device, key, true); if ((flags & release) != 0) SetKey(device, key, false); }
        void SetKey(long device, int key, bool down)
        {
            int index = Array.FindIndex(InputState.Bindings, delegate(Binding b) { return b.Key == key; });
            if (index < 0) return;
            HashSet<int> keys;
            if (!devices.TryGetValue(device, out keys)) { if (!down) return; keys = new HashSet<int>(); devices.Add(device, keys); }
            if (down)
            {
                if (keys.Add(key)) { taps[index] = true; last = "Last input: " + InputState.Bindings[index].Label; }
            }
            else keys.Remove(key);
        }
        bool IsDown(int key) { foreach (var keys in devices.Values) if (keys.Contains(key)) return true; return false; }
        public bool Refresh(InputState state)
        {
            bool changed = state.Update(IsDown, taps);
            if (last != null) state.Last = last;
            Array.Clear(taps, 0, taps.Length); last = null;
            return changed;
        }
        public void RemoveDevice(long device) { devices.Remove(device); }
        public void Clear() { devices.Clear(); Array.Clear(taps, 0, taps.Length); last = null; }
        public void Dispose()
        {
            if (source == null) return;
            Native.RegisterRawInputDevices(new[] {
                new Native.RawDevice { Page = 1, Usage = 6, Flags = 1 },
                new Native.RawDevice { Page = 1, Usage = 2, Flags = 1 }
            }, 2, (uint)Marshal.SizeOf(typeof(Native.RawDevice)));
            source.RemoveHook(Message); source = null; Clear();
        }
    }

    public class KeyVisual : FrameworkElement
    {
        public InputState State;
        public Preferences Settings;
        public bool Demo;
        public static readonly Color[] Colors = { Color.FromRgb(255, 96, 115), Color.FromRgb(88, 228, 187), Color.FromRgb(175, 145, 255) };
        public KeyVisual(InputState state, Preferences settings) { State = state; Settings = settings; Width = 230; Height = 356; }
        public static SolidColorBrush Brush(string color) { var b = (SolidColorBrush)new BrushConverter().ConvertFromString(color); b.Freeze(); return b; }
        static void Text(DrawingContext dc, string text, double size, Brush brush, double x, double y, bool bold, double center)
        {
            var ft = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, bold ? FontWeights.SemiBold : FontWeights.Normal, FontStretches.Normal), size, brush, 1.0);
            dc.DrawText(ft, new Point(center > 0 ? x + (center - ft.Width) / 2 : x, y));
        }
        protected override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);
            var accent = new SolidColorBrush(Colors[Settings.Theme]);
            var muted = Brush("#7E899D"); var ink = Brush("#E9EDF5");
            Text(dc, "T A P T R A C E", 9, muted, 14, 9, true, 0);
            dc.DrawEllipse(accent, null, new Point(209, 16), 3, 3);
            for (int i = 0; i < InputState.Bindings.Length; i++)
            {
                var b = InputState.Bindings[i]; var r = b.Bounds;
                bool pressed = Demo ? (int)(State.Clock.Elapsed.TotalMilliseconds / 420) % 10 == i : State.IsLit(i);
                dc.DrawRoundedRectangle(Brush("#66000000"), null, new Rect(r.X, r.Y + 3, r.Width, r.Height), 9, 9);
                dc.DrawRoundedRectangle(pressed ? accent : Brush("#EF171D29"), new Pen(pressed ? accent : Brush("#3B4557"), 1), r, 9, 9);
                var foreground = pressed ? Brush("#10151E") : ink;
                double size = i < 4 ? 25 : 12;
                double top = r.Y + (r.Height - (i < 4 ? 34 : b.Caption.Length > 0 ? 34 : 17)) / 2;
                Text(dc, b.Label, size, foreground, r.X, top, true, r.Width);
                if (b.Caption.Length > 0) Text(dc, b.Caption, 8, pressed ? Brush("#44232D") : muted, r.X, top + 20, false, r.Width);
            }
            dc.DrawLine(new Pen(Brush("#364052"), 1), new Point(14, 220), new Point(216, 220));
            Text(dc, "K E Y B O A R D", 7, muted, 14, 342, false, 0);
            Text(dc, "+   M O U S E", 7, muted, 149, 342, false, 0);
        }
    }

    public class OverlayWindow : Window
    {
        readonly Engine engine;
        public readonly KeyVisual Visual;
        IntPtr handle;
        public OverlayWindow(Engine e)
        {
            engine = e; Title = "TapTrace Overlay"; WindowStyle = WindowStyle.None;
            AllowsTransparency = true; Background = Brushes.Transparent; ResizeMode = ResizeMode.NoResize;
            Topmost = true; ShowInTaskbar = false; ShowActivated = false; SizeToContent = SizeToContent.WidthAndHeight;
            Visual = new KeyVisual(e.Input, e.Settings);
            var box = new Border { Background = Brushes.Transparent, Child = Visual };
            Content = box;
            SourceInitialized += delegate { handle = new WindowInteropHelper(this).Handle; Apply(); };
            MouseLeftButtonDown += delegate { if (!e.Settings.Locked) { DragMove(); e.Settings.X = Left; e.Settings.Y = Top; e.Save(); } };
            MouseRightButtonUp += delegate { if (!e.Settings.Locked) e.ShowControls(); };
        }
        public void Apply()
        {
            Visual.LayoutTransform = new ScaleTransform(engine.Settings.Scale, engine.Settings.Scale);
            Opacity = engine.Settings.Opacity;
            if (handle != IntPtr.Zero)
            {
                int style = Native.GetWindowLong(handle, -20);
                style |= 0x00000080 | 0x08000000; // Tool window; never take foreground focus.
                if (engine.Settings.Locked) style |= 0x20; else style &= ~0x20;
                Native.SetWindowLong(handle, -20, style);
            }
            Visual.InvalidateVisual();
        }
        public void RestorePosition()
        {
            double width = 230 * engine.Settings.Scale, height = 356 * engine.Settings.Scale;
            // Validate against each actual display, including displays left of the primary.
            bool reachable = false;
            var target = new Rect(engine.Settings.X, engine.Settings.Y, width, height);
            foreach (Forms.Screen screen in Forms.Screen.AllScreens)
            {
                var dpi = PresentationSource.FromVisual(this);
                var transform = dpi == null ? Matrix.Identity : dpi.CompositionTarget.TransformFromDevice;
                var area = screen.WorkingArea;
                var origin = transform.Transform(new Point(area.X, area.Y));
                var size = transform.Transform(new Vector(area.Width, area.Height));
                var intersection = Rect.Intersect(target, new Rect(origin.X, origin.Y, size.X, size.Y));
                if (!intersection.IsEmpty && intersection.Width >= Math.Min(width, 100) && intersection.Height >= Math.Min(height, 100)) reachable = true;
            }
            if (!reachable) { engine.Settings.X = SystemParameters.WorkArea.Left + 36; engine.Settings.Y = SystemParameters.WorkArea.Top + 80; }
            Left = engine.Settings.X; Top = engine.Settings.Y;
        }
    }

    public class ControlsWindow : Window
    {
        readonly Engine engine;
        public readonly KeyVisual Preview;
        readonly CheckBox locked, visible;
        readonly TextBlock inputStatus, stateStatus;
        readonly TextBlock permissionStatus, eventStatus;
        readonly Slider scale, opacity;
        bool syncing;
        public ControlsWindow(Engine e)
        {
            engine = e; Title = "TapTrace - Keystroke Overlay"; Width = 740; Height = 710;
            ResizeMode = ResizeMode.CanMinimize; WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = KeyVisual.Brush("#0D111A"); Foreground = KeyVisual.Brush("#EDF0F7"); FontFamily = new FontFamily("Segoe UI"); FontSize = 13;
            var root = new Grid { Margin = new Thickness(30, 24, 30, 22) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); Content = root;
            var header = new StackPanel();
            var brand = Label("T A P T R A C E", 24, "#F1F3F9"); brand.FontWeight = FontWeights.Bold; header.Children.Add(brand);
            header.Children.Add(Label("Your inputs. In the spotlight.", 13, "#8C98AE"));
            header.Margin = new Thickness(0, 0, 0, 24); root.Children.Add(header);
            var body = new Grid(); body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(290) }); Grid.SetRow(body, 1); root.Children.Add(body);
            var settings = new StackPanel(); body.Children.Add(settings);
            settings.Children.Add(Section("OVERLAY"));
            visible = Toggle("Show overlay", e.Settings.Visible); settings.Children.Add(visible);
            visible.Checked += delegate { ChangeVisible(true); }; visible.Unchecked += delegate { ChangeVisible(false); };
            locked = Toggle("Lock position / click through", e.Settings.Locked); locked.Margin = new Thickness(0, 12, 0, 6); settings.Children.Add(locked);
            locked.Checked += delegate { ChangeLock(true); }; locked.Unchecked += delegate { ChangeLock(false); };
            settings.Children.Add(Label("Unlock, then drag the overlay to move it.", 11, "#8C98AE"));
            settings.Children.Add(Label("Background keyboard + mouse input enabled", 10, "#58E4BB"));
            permissionStatus = Label("", 10, "#FF9EAA"); settings.Children.Add(permissionStatus);
            eventStatus = Label("", 10, "#8C98AE"); settings.Children.Add(eventStatus);
            if (!GameCompatibility.IsAdministrator())
            {
                var administrator = Button("Restart as administrator", e.RestartAsAdministrator);
                administrator.Margin = new Thickness(0, 7, 0, 0); administrator.HorizontalAlignment = HorizontalAlignment.Left;
                administrator.ToolTip = "Requests Windows approval to receive input from games running as administrator.";
                settings.Children.Add(administrator);
            }
            settings.Children.Add(Section("APPEARANCE"));
            var scaleValue = Label("", 12, "#D5DBE7"); settings.Children.Add(scaleValue);
            scale = new Slider { Minimum = 70, Maximum = 180, Value = e.Settings.Scale * 100, TickFrequency = 5, IsSnapToTickEnabled = true, Margin = new Thickness(0, 6, 0, 12) };
            scaleValue.Text = "Size   " + Math.Round(scale.Value) + "%";
            scale.ValueChanged += delegate { scaleValue.Text = "Size   " + Math.Round(scale.Value) + "%"; e.Settings.Scale = scale.Value / 100; e.Apply(); e.Overlay.RestorePosition(); e.Save(); }; settings.Children.Add(scale);
            var opacityValue = Label("Opacity   " + Math.Round(e.Settings.Opacity * 100) + "%", 12, "#D5DBE7"); settings.Children.Add(opacityValue);
            opacity = new Slider { Minimum = 30, Maximum = 100, Value = e.Settings.Opacity * 100, Margin = new Thickness(0, 6, 0, 12) };
            opacity.ValueChanged += delegate { opacityValue.Text = "Opacity   " + Math.Round(opacity.Value) + "%"; e.Settings.Opacity = opacity.Value / 100; e.Apply(); e.Save(); }; settings.Children.Add(opacity);
            settings.Children.Add(Label("Press color", 12, "#D5DBE7"));
            var colors = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 9, 0, 0) };
            string[] names = { "Coral", "Mint", "Lilac" };
            for (int i = 0; i < 3; i++)
            {
                int index = i; var button = Button(names[i], delegate { e.Settings.Theme = index; e.Apply(); e.Save(); });
                button.Foreground = new SolidColorBrush(KeyVisual.Colors[i]); button.Padding = new Thickness(12, 7, 12, 7); button.Margin = new Thickness(0, 0, 6, 0); colors.Children.Add(button);
            }
            settings.Children.Add(colors);
            var reset = Button("Reset position", delegate { e.Settings.X = SystemParameters.WorkArea.Left + 36; e.Settings.Y = SystemParameters.WorkArea.Top + 80; e.Overlay.RestorePosition(); e.Save(); });
            reset.Margin = new Thickness(0, 20, 0, 0); reset.HorizontalAlignment = HorizontalAlignment.Left; settings.Children.Add(reset);
            var previewCard = new Border { Background = KeyVisual.Brush("#141A25"), BorderBrush = KeyVisual.Brush("#273143"), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), Padding = new Thickness(20, 14, 20, 12) };
            Grid.SetColumn(previewCard, 2); body.Children.Add(previewCard);
            var previewPanel = new StackPanel(); previewCard.Child = previewPanel;
            var previewHeader = new Grid(); previewHeader.Children.Add(Label("LIVE PREVIEW", 10, "#95A2B9"));
            stateStatus = Label("", 10, "#58E4BB"); stateStatus.HorizontalAlignment = HorizontalAlignment.Right; previewHeader.Children.Add(stateStatus); previewPanel.Children.Add(previewHeader);
            Preview = new KeyVisual(e.Input, e.Settings) { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 0) }; previewPanel.Children.Add(Preview);
            inputStatus = Label(e.Input.Last, 11, "#A8B5CA"); inputStatus.HorizontalAlignment = HorizontalAlignment.Center; inputStatus.Margin = new Thickness(0, 9, 0, 0); previewPanel.Children.Add(inputStatus);
            var demo = Toggle("Animate preview", false); demo.FontSize = 11; demo.Margin = new Thickness(0, 10, 0, 0); demo.HorizontalAlignment = HorizontalAlignment.Center;
            demo.Checked += delegate { Preview.Demo = true; }; demo.Unchecked += delegate { Preview.Demo = false; Preview.InvalidateVisual(); }; previewPanel.Children.Add(demo);
            var footer = new Grid { Margin = new Thickness(0, 20, 0, 0) };
            var help = new StackPanel(); help.Children.Add(Label("F8  lock / move     F9  show / hide     F10  settings", 11, "#A2AEC3"));
            help.Children.Add(Label("Close this panel to keep the overlay in the system tray.", 10, "#748198")); footer.Children.Add(help);
            var exit = Button("Quit", delegate { e.Quit(); }); exit.HorizontalAlignment = HorizontalAlignment.Right; exit.VerticalAlignment = VerticalAlignment.Center; footer.Children.Add(exit);
            Grid.SetRow(footer, 2); root.Children.Add(footer);
            Closing += delegate(object sender, System.ComponentModel.CancelEventArgs args) { if (!e.Exiting) { args.Cancel = true; Hide(); } };
            Sync();
        }
        static TextBlock Label(string text, double size, string color) { return new TextBlock { Text = text, FontSize = size, Foreground = KeyVisual.Brush(color), Margin = new Thickness(0, 2, 0, 2) }; }
        static TextBlock Section(string text) { var t = Label(text, 10, "#78879F"); t.FontWeight = FontWeights.SemiBold; t.Margin = new Thickness(0, 18, 0, 13); return t; }
        static CheckBox Toggle(string text, bool value) { return new CheckBox { Content = text, IsChecked = value, Foreground = KeyVisual.Brush("#DDE4EF"), VerticalContentAlignment = VerticalAlignment.Center }; }
        static Button Button(string text, Action action)
        {
            var b = new Button { Content = text, Background = KeyVisual.Brush("#202A3A"), Foreground = KeyVisual.Brush("#DDE4EF"), BorderBrush = KeyVisual.Brush("#354158"), Padding = new Thickness(14, 8, 14, 8), Cursor = Cursors.Hand };
            // A small custom template keeps native light-theme chrome out of the dark panel.
            var border = new FrameworkElementFactory(typeof(Border)); border.SetValue(Border.CornerRadiusProperty, new CornerRadius(6));
            border.SetBinding(Border.BackgroundProperty, new System.Windows.Data.Binding("Background") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
            border.SetBinding(Border.PaddingProperty, new System.Windows.Data.Binding("Padding") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
            border.SetValue(Border.BorderThicknessProperty, new Thickness(1)); border.SetValue(Border.BorderBrushProperty, KeyVisual.Brush("#354158"));
            var content = new FrameworkElementFactory(typeof(ContentPresenter)); content.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center); border.AppendChild(content);
            b.Template = new ControlTemplate(typeof(Button)) { VisualTree = border };
            b.MouseEnter += delegate { b.Background = KeyVisual.Brush("#303E55"); }; b.MouseLeave += delegate { b.Background = KeyVisual.Brush("#202A3A"); };
            b.Click += delegate { action(); }; return b;
        }
        void ChangeVisible(bool value) { if (syncing) return; engine.Settings.Visible = value; engine.Apply(); engine.Save(); }
        void ChangeLock(bool value) { if (syncing) return; engine.Settings.Locked = value; engine.Apply(); engine.Save(); }
        public void Sync()
        {
            syncing = true; locked.IsChecked = engine.Settings.Locked; visible.IsChecked = engine.Settings.Visible;
            stateStatus.Text = engine.Settings.Visible ? (engine.Settings.Locked ? "LIVE / LOCKED" : "MOVE MODE") : "HIDDEN"; syncing = false;
        }
        public void RefreshInput() { inputStatus.Text = engine.Input.Last; }
        public void ShowNotice(string text) { inputStatus.Text = text; }
        public void RefreshDiagnostics(long keyboard, long mouse, bool elevatedGame)
        {
            permissionStatus.Text = GameCompatibility.IsAdministrator() ? "Administrator mode active" : elevatedGame ? "VALORANT runs as admin. Restart TapTrace as admin." : "Standard permissions";
            eventStatus.Text = "Input events: keyboard " + keyboard + " / mouse " + mouse;
        }
    }

    public class Engine
    {
        public Preferences Settings;
        public readonly InputState Input = new InputState();
        readonly RawInputSource rawInput = new RawInputSource();
        public OverlayWindow Overlay;
        public ControlsWindow Controls;
        public bool Exiting;
        readonly string settingsPath;
        Forms.NotifyIcon tray;
        DispatcherTimer timer, saveTimer;
        IntPtr controlHandle;
        readonly List<int> hotkeys = new List<int>();
        string saveError;
        string hotkeyError;
        int diagnosticTicks;
        bool elevatedGame;
        public Engine(string path)
        {
            settingsPath = path;
            string legacyPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Keycast", "settings.xml");
            string defaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TapTrace", "settings.xml");
            Settings = Load(!File.Exists(path) && string.Equals(path, defaultPath, StringComparison.OrdinalIgnoreCase) && File.Exists(legacyPath) ? legacyPath : path);
            Overlay = new OverlayWindow(this); Overlay.Show(); Overlay.RestorePosition();
            Controls = new ControlsWindow(this);
            Controls.SourceInitialized += delegate { SetupHotkeys(); rawInput.Start(controlHandle); };
            Microsoft.Win32.SystemEvents.SessionSwitch += SessionChanged;
            SetupTray();
            saveTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
            saveTimer.Tick += delegate { saveTimer.Stop(); WriteSettings(); };
            timer = new DispatcherTimer(DispatcherPriority.Input) { Interval = TimeSpan.FromMilliseconds(8) };
            timer.Tick += delegate {
                if (rawInput.Refresh(Input))
                {
                    if (Overlay.IsVisible) Overlay.Visual.InvalidateVisual();
                    if (Controls.IsVisible) { Controls.Preview.InvalidateVisual(); Controls.RefreshInput(); }
                }
                if (Controls.IsVisible && Controls.Preview.Demo) Controls.Preview.InvalidateVisual();
                if (++diagnosticTicks >= 125)
                {
                    diagnosticTicks = 0; elevatedGame = GameCompatibility.ElevatedGame();
                    if (Controls.IsVisible) Controls.RefreshDiagnostics(rawInput.KeyboardPackets, rawInput.MousePackets, elevatedGame);
                }
            };
            timer.Start(); Apply(); Controls.Show();
            if (hotkeyError != null) Controls.ShowNotice(hotkeyError);
        }
        public static Preferences Load(string path)
        {
            try { using (var f = File.OpenRead(path)) { var s = (Preferences)new XmlSerializer(typeof(Preferences)).Deserialize(f); s.Validate(); return s; } }
            catch (IOException) { return new Preferences(); }
            catch (UnauthorizedAccessException) { return new Preferences(); }
            catch (InvalidOperationException) { return new Preferences(); }
        }
        void SessionChanged(object sender, Microsoft.Win32.SessionSwitchEventArgs args)
        { Controls.Dispatcher.BeginInvoke(new Action(delegate { rawInput.Clear(); })); }
        void SetupHotkeys()
        {
            controlHandle = new WindowInteropHelper(Controls).Handle;
            var source = HwndSource.FromHwnd(controlHandle); source.AddHook(HotkeyMessage);
            for (int i = 0; i < 3; i++)
            {
                if (Native.RegisterHotKey(controlHandle, i + 1, 0x4000, (uint)(0x77 + i))) hotkeys.Add(i + 1);
                else hotkeyError = "A shortcut is in use; use the tray menu.";
            }
        }
        IntPtr HotkeyMessage(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (message == 0x0312)
            {
                if (wParam.ToInt32() == 1) { Settings.Locked = !Settings.Locked; Apply(); Save(); }
                if (wParam.ToInt32() == 2) { Settings.Visible = !Settings.Visible; Apply(); Save(); }
                if (wParam.ToInt32() == 3) ShowControls();
                handled = true;
            }
            return IntPtr.Zero;
        }
        void SetupTray()
        {
            tray = new Forms.NotifyIcon { Text = "TapTrace - keystroke overlay", Visible = true };
            using (var icon = System.Drawing.Icon.ExtractAssociatedIcon(System.Reflection.Assembly.GetExecutingAssembly().Location)) tray.Icon = (System.Drawing.Icon)icon.Clone();
            var menu = new Forms.ContextMenuStrip();
            menu.Items.Add("Open settings (F10)", null, delegate { ShowControls(); });
            menu.Items.Add("Lock / unlock (F8)", null, delegate { Settings.Locked = !Settings.Locked; Apply(); Save(); });
            menu.Items.Add("Show / hide (F9)", null, delegate { Settings.Visible = !Settings.Visible; Apply(); Save(); });
            menu.Items.Add(new Forms.ToolStripSeparator()); menu.Items.Add("Quit TapTrace", null, delegate { Quit(); });
            tray.ContextMenuStrip = menu; tray.DoubleClick += delegate { ShowControls(); };
        }
        public void ShowControls() { Controls.Show(); Controls.WindowState = WindowState.Normal; Controls.Activate(); }
        public void RestartAsAdministrator()
        {
            try
            {
                WriteSettings();
                Process.Start(new ProcessStartInfo(System.Reflection.Assembly.GetExecutingAssembly().Location) {
                    UseShellExecute = true, Verb = "runas",
                    Arguments = "--restart " + Process.GetCurrentProcess().Id + " --settings \"" + settingsPath + "\""
                });
                Quit();
            }
            catch (System.ComponentModel.Win32Exception ex)
            { Controls.ShowNotice(ex.NativeErrorCode == 1223 ? "Administrator restart cancelled; TapTrace is still running." : "Administrator restart failed: " + ex.Message); }
        }
        public void Apply()
        {
            Overlay.Apply(); if (Settings.Visible) Overlay.Show(); else Overlay.Hide();
            if (Controls != null) { Controls.Sync(); Controls.Preview.InvalidateVisual(); }
        }
        public void Save() { if (saveTimer != null) { saveTimer.Stop(); saveTimer.Start(); } }
        void WriteSettings()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(settingsPath));
                string temporary = settingsPath + ".tmp";
                using (var f = File.Create(temporary)) new XmlSerializer(typeof(Preferences)).Serialize(f, Settings);
                if (File.Exists(settingsPath)) File.Replace(temporary, settingsPath, null); else File.Move(temporary, settingsPath);
                saveError = null;
            }
            catch (Exception ex) { if (!(ex is IOException) && !(ex is UnauthorizedAccessException)) throw; saveError = "Settings could not be saved to disk."; Controls.ShowNotice(saveError); }
        }
        public void Quit()
        {
            if (Exiting) return; Exiting = true; timer.Stop(); saveTimer.Stop(); WriteSettings();
            foreach (int id in hotkeys) Native.UnregisterHotKey(controlHandle, id);
            rawInput.Dispose(); Microsoft.Win32.SystemEvents.SessionSwitch -= SessionChanged;
            tray.Visible = false; tray.Dispose(); Overlay.Close(); Controls.Close(); Application.Current.Shutdown();
        }
    }

    public static class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            if (args.Length >= 2 && args[0] == "--self-test") return SelfTest(args[1]);
            if (args.Length >= 2 && args[0] == "--restart")
            {
                int previous;
                if (!int.TryParse(args[1], out previous)) return 1;
                try
                {
                    using (var process = Process.GetProcessById(previous))
                    {
                        if (process.ProcessName.Equals("TapTrace", StringComparison.OrdinalIgnoreCase) && !process.WaitForExit(15000))
                        { MessageBox.Show("Close the previous TapTrace instance, then reopen TapTrace.", "TapTrace"); return 1; }
                    }
                }
                catch (ArgumentException) { /* Previous instance already exited. */ }
                var remaining = new string[args.Length - 2]; Array.Copy(args, 2, remaining, 0, remaining.Length); args = remaining;
            }
            bool created;
            using (var mutex = new Mutex(true, "Local\\TapTraceOverlay.Desktop.v1", out created))
            {
                if (!created) { MessageBox.Show("TapTrace is already running. Press F10 or use its system tray icon to open settings.", "TapTrace"); return 0; }
                try
                {
                    string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TapTrace", "settings.xml");
                    if (args.Length >= 2 && args[0] == "--settings") path = Path.GetFullPath(args[1]);
                    var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
                    new Engine(path); app.Run();
                }
                catch (Exception ex) { MessageBox.Show("TapTrace could not start:\n" + ex.Message, "TapTrace", MessageBoxButton.OK, MessageBoxImage.Error); return 1; }
                return 0;
            }
        }
        static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
        static byte[] TestPacket(int pointerSize, uint type, long device, int scan, int flags, int key)
        {
            int header = 8 + pointerSize * 2;
            var data = new byte[header + (type == 1 ? 16 : 24)];
            Buffer.BlockCopy(BitConverter.GetBytes(type), 0, data, 0, 4);
            Buffer.BlockCopy(BitConverter.GetBytes((uint)data.Length), 0, data, 4, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(device), 0, data, 8, pointerSize);
            if (type == 1)
            {
                Buffer.BlockCopy(BitConverter.GetBytes((ushort)scan), 0, data, header, 2);
                Buffer.BlockCopy(BitConverter.GetBytes((ushort)flags), 0, data, header + 2, 2);
                Buffer.BlockCopy(BitConverter.GetBytes((ushort)key), 0, data, header + 6, 2);
            }
            else Buffer.BlockCopy(BitConverter.GetBytes((ushort)flags), 0, data, header + 4, 2);
            return data;
        }
        static void TestRawInput()
        {
            foreach (int pointerSize in new[] { 4, 8 })
            {
                var receiver = new RawInputSource(); var state = new InputState();
                for (int i = 0; i < 10; i++)
                {
                    receiver.Clear();
                    int key = InputState.Bindings[i].Key;
                    int scan = i == 4 ? 0x2A : i == 5 ? 0x1D : 0x11;
                    int vkey = i == 4 ? 0x10 : i == 5 ? 0x11 : key;
                    int[] mouseDown = { 1, 4, 0x40, 0x100 };
                    var down = TestPacket(pointerSize, i < 6 ? 1u : 0u, 1, scan, i < 6 ? 0 : mouseDown[i - 6], vkey);
                    receiver.Parse(down, down.Length, pointerSize); receiver.Refresh(state);
                    for (int j = 0; j < 10; j++) Check(state.Down[j] == (i == j), "Raw press mapping failed at " + i);
                    var up = TestPacket(pointerSize, i < 6 ? 1u : 0u, 1, scan, i < 6 ? 1 : mouseDown[i - 6] * 2, vkey);
                    receiver.Parse(up, up.Length, pointerSize); receiver.Refresh(state);
                    Check(!state.Down[i], "Raw release mapping failed at " + i);
                }
                var rightShift = TestPacket(pointerSize, 1, 1, 0x36, 0, 0x10);
                var rightCtrl = TestPacket(pointerSize, 1, 1, 0x1D, 2, 0x11);
                receiver.Parse(rightShift, rightShift.Length, pointerSize); receiver.Parse(rightCtrl, rightCtrl.Length, pointerSize); receiver.Refresh(state);
                Check(!state.Down[4] && !state.Down[5], "Right modifiers must not light left modifiers");
                var w1 = TestPacket(pointerSize, 1, 1, 0x11, 0, 0x57);
                var w2 = TestPacket(pointerSize, 1, 2, 0x11, 0, 0x57);
                var wUp = TestPacket(pointerSize, 1, 1, 0x11, 1, 0x57);
                receiver.Parse(w1, w1.Length, pointerSize); receiver.Parse(w2, w2.Length, pointerSize);
                receiver.Parse(wUp, wUp.Length, pointerSize); receiver.Refresh(state);
                Check(state.Down[0], "Releasing one keyboard must preserve another keyboard's held key");
                receiver.RemoveDevice(2); receiver.Refresh(state); Check(!state.Down[0], "Device removal must release held keys");
                receiver.Clear(); state = new InputState();
                receiver.Parse(w1, w1.Length, pointerSize); receiver.Parse(wUp, wUp.Length, pointerSize); receiver.Refresh(state);
                Check(!state.Down[0] && state.IsLit(0), "A tap between repaint ticks must remain visible");
                var mouse = TestPacket(pointerSize, 0, 3, 0, 0x0145, 0);
                receiver.Parse(mouse, mouse.Length, pointerSize); receiver.Refresh(state);
                Check(state.Down[6] && state.Down[7] && state.Down[8] && state.Down[9], "Combined mouse button flags failed");
                receiver.Clear(); receiver.Parse(new byte[2], 2, pointerSize); receiver.Parse(mouse, 8, pointerSize); receiver.Refresh(state);
                foreach (bool held in state.Down) Check(!held, "Malformed raw packet must be ignored");
            }
            using (var window = new HwndSource(new HwndSourceParameters("TapTrace raw input registration test") { Width = 0, Height = 0, WindowStyle = unchecked((int)0x80000000) }))
            using (var receiver = new RawInputSource())
            {
                receiver.Start(window.Handle);
                uint count = 8; var registrations = new Native.RawDevice[count];
                uint found = Native.GetRegisteredRawInputDevices(registrations, ref count, (uint)Marshal.SizeOf(typeof(Native.RawDevice)));
                Check(found != uint.MaxValue, "Reading live Raw Input registration failed");
                int matches = 0;
                for (int i = 0; i < found; i++)
                    if (registrations[i].Page == 1 && (registrations[i].Usage == 2 || registrations[i].Usage == 6) && (registrations[i].Flags & 0x100) != 0 && registrations[i].Target == window.Handle) matches++;
                Check(matches == 2, "Keyboard and mouse must both be registered for foreground-independent input");
            }
        }
        static int SelfTest(string directory)
        {
            Directory.CreateDirectory(directory);
            try
            {
                new Application();
                TestRawInput();
                var input = new InputState();
                Check(InputState.Bindings.Length == 10, "Expected ten inputs");
                var codes = new HashSet<int>();
                foreach (var binding in InputState.Bindings) Check(codes.Add(binding.Key), "Duplicate binding");
                Check(InputState.Bindings[4].Key == 0xA0 && InputState.Bindings[5].Key == 0xA2, "Modifiers must be left-specific");
                Check(InputState.Bindings[8].Key == 5 && InputState.Bindings[9].Key == 6, "Incorrect side mouse mapping");
                for (int i = 0; i < 10; i++)
                {
                    int code = InputState.Bindings[i].Key;
                    input.Update(delegate(int key) { return key == code; });
                    for (int j = 0; j < 10; j++) Check(input.Down[j] == (i == j), "Incorrect input state");
                }
                input.Update(delegate(int key) { return true; });
                for (int i = 0; i < 10; i++) Check(input.Down[i], "Simultaneous press failed");
                input.Update(delegate(int key) { return false; });
                for (int i = 0; i < 10; i++) Check(!input.Down[i], "Release failed");
                Thread.Sleep(110);
                Check(input.Update(delegate(int key) { return false; }), "Release highlight must repaint after expiry");
                for (int i = 0; i < 10; i++) Check(!input.IsLit(i), "Release highlight stuck");
                var settings = new Preferences { Scale = double.NaN, Opacity = 12, Theme = 20 }; settings.Validate();
                Check(settings.Scale == 1 && settings.Opacity == 1 && settings.Theme == 2, "Invalid setting sanitization failed");
                settings = new Preferences { Scale = 1.35, Theme = 1, X = -400, Locked = false };
                string xml = Path.Combine(directory, "roundtrip.xml");
                using (var stream = File.Create(xml)) new XmlSerializer(typeof(Preferences)).Serialize(stream, settings);
                var loaded = Engine.Load(xml); Check(loaded.Scale == 1.35 && loaded.X == -400 && !loaded.Locked && loaded.Theme == 1, "Settings roundtrip failed");
                File.WriteAllText(xml, "invalid xml"); Check(Engine.Load(xml).Scale == 1, "Corrupt settings recovery failed");
                input.Update(delegate(int key) { return key == 0x57 || key == 0x01 || key == 0xA0; });
                for (int i = 0; i < 10; i++) input.LitUntil[i] = 0;
                var visual = new KeyVisual(input, new Preferences());
                visual.Measure(new Size(230, 356)); visual.Arrange(new Rect(0, 0, 230, 356));
                var bitmap = new RenderTargetBitmap(460, 712, 192, 192, PixelFormats.Pbgra32); bitmap.Render(visual);
                var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
                using (var stream = File.Create(Path.Combine(directory, "overlay-preview.png"))) png.Save(stream);
                File.WriteAllText(Path.Combine(directory, "test-result.txt"), "PASS: live Windows background Raw Input registration for keyboard and mouse; x86/x64 raw packet parsing; all ten raw press/release mappings; right modifiers excluded; multi-device held keys; unplug releases; sub-frame tap capture; combined mouse flags; malformed packet handling; ten bindings; simultaneous presses; release and highlight expiry; settings validation; XML roundtrip; corrupt settings recovery; transparent overlay rendering.\n");
                return 0;
            }
            catch (Exception ex) { File.WriteAllText(Path.Combine(directory, "test-result.txt"), "FAIL: " + ex); return 1; }
        }
    }
}

