# TapTrace

A small, portable Windows keystroke overlay. Run **dist/TapTrace.exe**. No installer, Node, Python, or .NET SDK is needed. Uses the .NET Framework 4.8 desktop components supplied with Windows 10/11. Standard desktop use runs without administrator access; games running as administrator may require TapTrace to run at the same permission level.

## Inputs

| Display | Physical input |
| --- | --- |
| W / A / S / D | Movement keys |
| L SHIFT | Left Shift only |
| L CTRL | Left Control only |
| LMB / RMB | Left / right mouse buttons |
| M4 · BACK | Mouse button 4, XBUTTON1 |
| M5 · FORWARD | Mouse button 5, XBUTTON2 |

Highlights work while other apps have focus, and multiple keys can light up together. A short 85 ms highlight keeps quick taps visible. Physical mouse buttons are detected; software that remaps a side button into a keyboard key may need its normal mouse-button assignment restored.

## Controls

- **F8:** lock or unlock the overlay. When unlocked, drag any key to move it; right-click it to open settings. When locked, clicks pass through to the app underneath.
- **F9:** show or hide the overlay.
- **F10:** open settings.
- Change size, opacity, and the press color in settings. **Animate preview** only animates the panel preview; the desktop overlay always shows live inputs.
- Closing settings keeps the overlay running in the system tray. Double-click its tray icon to reopen settings, or use the tray menu for the same controls. **Quit** exits the app.
- If another app owns a shortcut, use the tray menu.
- **Restart as administrator:** use this when the permission status says VALORANT is running as administrator. Windows asks you to approve the restart. Cancelling keeps TapTrace running normally, and accepting preserves settings and replaces the old instance. The app never changes VALORANT's permissions.
- The settings panel shows keyboard/mouse event counts. These are in-memory counts, not a record of typed text, and help distinguish input reception from display problems.

Preferences are saved to `%LOCALAPPDATA%\TapTrace\settings.xml`. To use a different location, launch `TapTrace.exe --settings "C:\path\settings.xml"`. Position is checked against connected monitors at startup and after resizing.

Use windowed or borderless-windowed game mode for a normal desktop overlay. Exclusive fullscreen may cover it. This build receives physical keyboard and mouse events through Windows Raw Input with `RIDEV_INPUTSINK`, including while another application uses Raw Input in the foreground. It replaces the original key-state polling, which could stop reporting presses while VALORANT had focus. It does not inject code into games, install a driver, record typed text, or use the network. Actual VALORANT behavior still needs a live check on your machine; the Windows registration and event parsing are tested.

## Build

Run `powershell -ExecutionPolicy Bypass -File .\build.ps1` from this folder. The script uses the Windows .NET Framework C# compiler and produces `dist/TapTrace.exe` and its runtime configuration.

## Verify

Run `dist\TapTrace.exe --self-test tests-output` and wait for it to exit. Read `tests-output/test-result.txt` for results. The checks verify actual background Raw Input registration with Windows, 32/64-bit packet parsing, all ten raw press/release mappings, right-modifier exclusion, simultaneous mouse flags, multiple keyboards, unplug recovery, taps between repaint ticks, malformed packets, release and highlight expiry, preference validation, serialization, corrupt preference recovery, and an actual WPF render. `tests-output/overlay-preview.png` shows W, Left Shift, and LMB pressed.

Windows API references: [background Raw Input registration](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-rawinputdevice), [GetRawInputData](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getrawinputdata), [RAWKEYBOARD](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-rawkeyboard), and [RAWMOUSE](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-rawmouse).

